export const CST = {
    SCENES: {
        PRELOAD: "PRELOAD",
        LOAD: "LOAD",
        INSTRUCTION: "INSTRUCTION",
        GAME: "GAME",
        GAMEANSWER: "GAMEANSWER",
        DONE: "DONE"
    },
    SPLASH: "Detailed"
}